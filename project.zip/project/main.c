#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "function.h"
#include "datatypes.h"

#define adminEmail "admin@copilot.com"
#define adminPassword "123@123"

bool checkPass(char *email,char *password){
	return (strcmp(email,adminEmail)==0 && strcmp(password, adminPassword)==0);
}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char email[50];
	char password[50];
	int choice;
	int adminChoice;
	int n;
	
	do{
		firstMenu();
		scanf("%d", &choice);
		switch(choice){
			case 1:
				fflush(stdin);
				system("cls");
				loginAdmin(email,password);
				printf("|[1]. Email:  ");
				fgets(email,sizeof(email),stdin);
				email[strcspn(email, "\n")] = '\0';
				printf("|[2]. Password:  ");
				fgets(password,sizeof(password),stdin);
				password[strcspn(password, "\n")] = '\0';
				if(checkPass(email,password)){
					printf("\nLogin successful!\n");
				}
				printf("|====================================|\n");
				do{
					adminMenu();
					scanf("%d", &adminChoice);				
					switch(adminChoice){
						case 1:
							showProduct();
							break;
						case 2:
							addProduct();
							break;
						case 3:
							break;
						case 4:
							break;
						case 5:
							break;
						case 6:
							break;
						case 7:
							break;
						default:
							break;
					}
					
					}while(choice != 7);
					
			
		}
	}while(choice!=0);
	return 0;
}
