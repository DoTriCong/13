#include "function.h"
#include <stdio.h>
#include "datatypes.h"

// logic ham
// Giao dien man hinh chinh
void firstMenu(){
	printf ("*****Candy Crush Store Management*****\n");
	printf("|          Choose your role           |\n");
	printf("|=====================================|\n");
	printf("|[1]. Admin                           |\n");
	printf("|[0]. Exit                            |\n");
	printf("|=====================================|\n");
	printf("Your choice is: ");
}
//dang nhap tai khoan
void loginAdmin(char email[], char password[]){
	printf("*****Candy Crush Store Management*****\n");
	printf("|               LOGIN                |\n");
	printf("=====================================|\n");
}
void adminMenu(){
	printf ("*****Candy Crush Store Management*****\n");
	printf("|          Product Management         |\n");
	printf("|=====================================|\n");
	printf("[1]. Hien thi cac san pham co san.    |\n");
	printf("[2]. Them san pham.                   |\n");
	printf("[3]. Sua san pham.                    |\n");
	printf("[4]. Xoa san pham.                    |\n");
	printf("[5]. Sap xep san pham.                |\n");
	printf("[6]. Tim kiem san pham.               |\n");
	printf("[7]. Exit.                            |\n");
	printf("|=====================================|\n");
	printf("Your choice is: ");
}
void showProduct(){
	printf("Danh sach cac san pham keo co trong cua hang:\n");
	printf("|======|====================|===============|===============|========|\n");
	printf("| %-5s | %-20s | %-15s | %-10s | %-10s |\n", "STT", "Ten San Pham", "Loai San Pham", "Gia tien", "So luong");
	printf("|======|====================|===============|===============|========|\n");

	for(int i=0; i<sizeof(MAX_PRODUCT)/sizeof(Product); i++){
		if(MAX_PRODUCT[i].id !=0) {
			printf("| %-4d | %-18s | %-13s | %-13.2f VND | %-6d | \n",
			       MAX_PRODUCT[i].id,MAX_PRODUCT[i].nameCandy,MAX_PRODUCT[i].typeCandy,MAX_PRODUCT[i].price,MAX_PRODUCT[i].quantity);
		}
	}
	printf("|======|====================|===============|===============|=========|\n");
}

