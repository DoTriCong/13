#include "datatypes.h"

//Nguyen mau ham giao dien chinh
void firstMenu();
void loginAdmin(char email[], char password[]);
void adminMenu();
void viewProduct();
void addProduct();

