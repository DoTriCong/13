#include <stdbool.h>
# pragma once
int choice, adminChoice;

char email[50];
char password[50];
typedef struct{
	int id;
	char nameCandy[50];
	char typeCandy[50];
	float price;
	int quantity;
} Product;
Product MAX_PRODUCT[100]={
	{1, "Keo deo Duc", "Keo deo", 29000, 20},
	{2, "Masmalow", "Keo deo", 30000, 10},
	{3, "Keo noel", "Keo cung", 15000, 35},
	{4, "Chip chip", "Keo deo", 18000, 20},
	{5, "Keo bac ha", "Keo ngam ho", 50000, 40}
	};
